/*
Nama : Rakyan Jenar s
kelas : XI RPL 4
absen : 28
 */


fun main(){
    println("hello kotlin!")
}

