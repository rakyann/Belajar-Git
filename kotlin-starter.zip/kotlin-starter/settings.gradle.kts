rootProject.name = "kotlin-starter"

